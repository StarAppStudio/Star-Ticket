import discord
from discord.ext import commands
from discord.utils import get

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="ticket!", intents=intents)

ticket_category_name = "🎫 Tickets"
log_channel_name = "📑ticket-logs"

@bot.event
async def on_ready():
    print(f"Bot ist bereit: {bot.user}")

@bot.command()
async def ez(ctx):
    guild = ctx.guild

    # Ticket Kategorie erstellen
    category = get(guild.categories, name=ticket_category_name)
    if not category:
        category = await guild.create_category(ticket_category_name)

    # Log Channel erstellen
    log_channel = get(guild.text_channels, name=log_channel_name)
    if not log_channel:
        log_channel = await guild.create_text_channel(log_channel_name)

    # Embed + Reactions
    panel = await ctx.send(
        embed=discord.Embed(title="🎟 Ticket Panel", description="❓ Allgemein\n❗ Wichtig\n🤝🏻 Partnerschaft", color=0x00ffcc)
    )
    for emoji in ["❓", "❗", "🤝🏻"]:
        await panel.add_reaction(emoji)

@bot.event
async def on_raw_reaction_add(payload):
    if payload.member == bot.user or payload.channel_id != payload.message_id:
        return

    guild = bot.get_guild(payload.guild_id)
    category = get(guild.categories, name=ticket_category_name)
    user = payload.member

    emoji_map = {
        "❓": "ticket-allgemein",
        "❗": "ticket-wichtig",
        "🤝🏻": "ticket-partnerschaft"
    }

    emoji = str(payload.emoji)
    if emoji in emoji_map:
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            get(guild.roles, name="Mod"): discord.PermissionOverwrite(read_messages=True)
        }
        ticket_channel = await guild.create_text_channel(
            name=f"{emoji_map[emoji]}-{user.name}", category=category, overwrites=overwrites
        )
        await ticket_channel.send(f"{user.mention} Willkommen! Warte auf ein Teammitglied. 🖐 = claim, ❌ = löschen")

@bot.command()
async def claim(ctx):
    await ctx.send(f"{ctx.author.mention} hat dieses Ticket übernommen.")
    await ctx.channel.set_permissions(ctx.guild.default_role, read_messages=False)
    await ctx.channel.set_permissions(ctx.author, read_messages=True, send_messages=True)

@bot.command()
async def closed(ctx):
    await ctx.send("🔒 Ticket wird geschlossen...")
    await ctx.channel.delete()

@bot.command()
async def plus(ctx, member: discord.Member):
    await ctx.channel.set_permissions(member, read_messages=True, send_messages=True)
    await ctx.send(f"{member.mention} wurde hinzugefügt.")

@bot.command()
async def help(ctx):
    help_text = """
**🎟 Ticket Bot Befehle**
`ticket!ez` - Erstellt das Setup mit Reaktionen
`ticket!claim` - Übernimmt das Ticket
`ticket!closed` - Schließt das Ticket
`ticket!plus @user` - Fügt jemand zum Ticket hinzu
`ticket!help` - Zeigt diese Hilfe
"""
    await ctx.send(help_text) 

from keep_alive import keep_alive
import os
from dotenv import load_dotenv
load_dotenv()
keep_alive()
bot.run(os.getenv("TOKEN"))
